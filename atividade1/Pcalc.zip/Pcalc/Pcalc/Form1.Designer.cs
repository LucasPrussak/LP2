﻿namespace Pcalc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblNum1 = new Label();
            lblNum2 = new Label();
            lblResult = new Label();
            txtNum1 = new TextBox();
            txtResult = new TextBox();
            txtNum2 = new TextBox();
            btnLimpar = new Button();
            btnSair = new Button();
            btnSomar = new Button();
            btnSubtrair = new Button();
            btnMulti = new Button();
            btnDivsão = new Button();
            listBox1 = new ListBox();
            SuspendLayout();
            // 
            // lblNum1
            // 
            lblNum1.AutoSize = true;
            lblNum1.Location = new Point(65, 98);
            lblNum1.Name = "lblNum1";
            lblNum1.Size = new Size(92, 25);
            lblNum1.TabIndex = 0;
            lblNum1.Text = "Numero 1";
            lblNum1.Click += label1_Click;
            // 
            // lblNum2
            // 
            lblNum2.AutoSize = true;
            lblNum2.Location = new Point(65, 185);
            lblNum2.Name = "lblNum2";
            lblNum2.Size = new Size(92, 25);
            lblNum2.TabIndex = 1;
            lblNum2.Text = "Numero 2";
            // 
            // lblResult
            // 
            lblResult.AutoSize = true;
            lblResult.Location = new Point(65, 269);
            lblResult.Name = "lblResult";
            lblResult.Size = new Size(90, 25);
            lblResult.TabIndex = 2;
            lblResult.Text = "Resultado";
            // 
            // txtNum1
            // 
            txtNum1.Location = new Point(310, 92);
            txtNum1.Name = "txtNum1";
            txtNum1.Size = new Size(150, 31);
            txtNum1.TabIndex = 3;
            txtNum1.Validated += txtNum1_Validated;
            // 
            // txtResult
            // 
            txtResult.Location = new Point(310, 263);
            txtResult.Name = "txtResult";
            txtResult.ReadOnly = true;
            txtResult.Size = new Size(150, 31);
            txtResult.TabIndex = 4;
            // 
            // txtNum2
            // 
            txtNum2.Location = new Point(310, 182);
            txtNum2.Name = "txtNum2";
            txtNum2.Size = new Size(150, 31);
            txtNum2.TabIndex = 5;
            txtNum2.TextChanged += txtNum2_TextChanged;
            txtNum2.Validated += txtNum2_Validated;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(573, 93);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(112, 34);
            btnLimpar.TabIndex = 6;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(573, 180);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(112, 34);
            btnSair.TabIndex = 7;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // btnSomar
            // 
            btnSomar.Location = new Point(35, 371);
            btnSomar.Name = "btnSomar";
            btnSomar.Size = new Size(112, 34);
            btnSomar.TabIndex = 8;
            btnSomar.Text = "+";
            btnSomar.UseVisualStyleBackColor = true;
            btnSomar.Click += btnSomar_Click;
            // 
            // btnSubtrair
            // 
            btnSubtrair.Location = new Point(188, 371);
            btnSubtrair.Name = "btnSubtrair";
            btnSubtrair.Size = new Size(112, 34);
            btnSubtrair.TabIndex = 9;
            btnSubtrair.Text = "-";
            btnSubtrair.UseVisualStyleBackColor = true;
            btnSubtrair.Click += btnSubtrair_Click;
            // 
            // btnMulti
            // 
            btnMulti.Location = new Point(358, 371);
            btnMulti.Name = "btnMulti";
            btnMulti.Size = new Size(112, 34);
            btnMulti.TabIndex = 10;
            btnMulti.Text = "*";
            btnMulti.UseVisualStyleBackColor = true;
            btnMulti.Click += btnMulti_Click;
            // 
            // btnDivsão
            // 
            btnDivsão.Location = new Point(524, 371);
            btnDivsão.Name = "btnDivsão";
            btnDivsão.Size = new Size(112, 34);
            btnDivsão.TabIndex = 11;
            btnDivsão.Text = "/";
            btnDivsão.UseVisualStyleBackColor = true;
            btnDivsão.Click += btnDivsão_Click;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 25;
            listBox1.Location = new Point(747, 93);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(153, 304);
            listBox1.TabIndex = 12;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1027, 584);
            Controls.Add(listBox1);
            Controls.Add(btnDivsão);
            Controls.Add(btnMulti);
            Controls.Add(btnSubtrair);
            Controls.Add(btnSomar);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(txtNum2);
            Controls.Add(txtResult);
            Controls.Add(txtNum1);
            Controls.Add(lblResult);
            Controls.Add(lblNum2);
            Controls.Add(lblNum1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblNum1;
        private Label lblNum2;
        private Label lblResult;
        private TextBox txtNum1;
        private TextBox txtResult;
        private TextBox txtNum2;
        private Button btnLimpar;
        private Button btnSair;
        private Button btnSomar;
        private Button btnSubtrair;
        private Button btnMulti;
        private Button btnDivsão;
        private ListBox listBox1;
    }
}
