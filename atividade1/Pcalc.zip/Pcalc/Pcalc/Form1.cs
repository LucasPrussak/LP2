namespace Pcalc
{
    public partial class Form1 : Form
    {
        double num1;
        double num2;
        double resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {

            if (!double.TryParse(txtNum1.Text, out num1))
            {
                MessageBox.Show("Uma calculadora s� aceita n�meros");
                txtNum1.Focus();
            }
        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum2.Text, out num2))
            {
                MessageBox.Show("Uma calculadora s� aceita n�meros");
                txtNum2.Focus();
            }
        }

        private void btnSomar_Click(object sender, EventArgs e)
        {
            resultado = num1 + num2;
            txtResult.Text = resultado.ToString();
            listBox1.Items.Add(""+ num1 + " + " + num2 + " = " + resultado);
        }

        private void btnSubtrair_Click(object sender, EventArgs e)
        {
            resultado = num1 - num2;
            txtResult.Text = resultado.ToString();
            listBox1.Items.Add("" + num1 + " - " + num2 + " = " + resultado);

        }

        private void btnMulti_Click(object sender, EventArgs e)
        {
            resultado = num1 * num2;
            txtResult.Text = resultado.ToString();
            listBox1.Items.Add("" + num1 + " * " + num2 + " = " + resultado);

        }

        private void btnDivs�o_Click(object sender, EventArgs e)
        {
            if (num2 == 0)
            {
                MessageBox.Show("N�o podemos dividir por zero");
                txtNum2.Text = "";
                txtNum2.Focus();
            }
            else
            {
                resultado = num1 / num2;
                txtResult.Text = resultado.ToString();
                listBox1.Items.Add("" + num1 + " / " + num2 + " = " + resultado);
            }
        }

        private void txtNum2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Text = "0";
            txtNum2.Text = "0";
            txtResult.Text = "0";
        }
    }
}
