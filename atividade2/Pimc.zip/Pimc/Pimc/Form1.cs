using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double altura, peso, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void mskPesoAtual_Validated(object sender, EventArgs e)
        {

            if (!double.TryParse(mskPesoAtual.Text, out peso))
            {
                MessageBox.Show("Digite apenas n�meros");
                mskPesoAtual.Focus();
            }
            if (peso == 0)
            {
                MessageBox.Show("Peso n�o pode ser zero!");
                mskPesoAtual.Text = "";
                mskPesoAtual.Focus();
            }

        }

        private void mskAltura_Validated(object sender, EventArgs e)
        {

            if (!double.TryParse(mskAltura.Text, out altura))
            {
                MessageBox.Show("Digite apenas n�meros");
                mskAltura.Focus();
            }
            if (altura == 0)
            {
                MessageBox.Show("Altura n�o pode ser zero!");
                mskPesoAtual.Text = "";
                mskPesoAtual.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (altura == 0 || peso == 0)
            {
                MessageBox.Show("Altura n�o pode ser zero!");
                mskPesoAtual.Text = "";
                mskPesoAtual.Focus();
            }
            else
            {
                imc = peso / Math.Pow(altura, 2);
                imc = Math.Round(imc, 1);
                mskIMC.Text = imc.ToString("n1");

                if (imc <= 18.5)
                {
                    MessageBox.Show("Classificacao: Magreza");
                }
                else if (imc <= 24.9)
                {
                    MessageBox.Show("Classificacao: Normal");
                }
                else if (imc <= 29.9)
                {
                    MessageBox.Show("Classificacao: Sobrepeso");
                }
                else if (imc <= 39.9)
                {
                    MessageBox.Show("Classificacao: Obesidade");
                }
                else
                {
                    MessageBox.Show("Classificacao: Obesidade grave");
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskAltura.Text = "";
            mskPesoAtual.Text = "";
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
