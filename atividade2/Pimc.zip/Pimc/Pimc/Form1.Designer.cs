﻿namespace Pimc
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblPesoAtual = new Label();
            lblAltura = new Label();
            lblIMC = new Label();
            mskPesoAtual = new MaskedTextBox();
            mskAltura = new MaskedTextBox();
            mskIMC = new MaskedTextBox();
            btnCalcular = new Button();
            btnLimpar = new Button();
            btnSair = new Button();
            SuspendLayout();
            // 
            // lblPesoAtual
            // 
            lblPesoAtual.AutoSize = true;
            lblPesoAtual.Location = new Point(75, 48);
            lblPesoAtual.Name = "lblPesoAtual";
            lblPesoAtual.Size = new Size(95, 25);
            lblPesoAtual.TabIndex = 0;
            lblPesoAtual.Text = "Peso Atual";
            // 
            // lblAltura
            // 
            lblAltura.AutoSize = true;
            lblAltura.Location = new Point(75, 135);
            lblAltura.Name = "lblAltura";
            lblAltura.Size = new Size(59, 25);
            lblAltura.TabIndex = 1;
            lblAltura.Text = "Altura";
            // 
            // lblIMC
            // 
            lblIMC.AutoSize = true;
            lblIMC.Location = new Point(75, 228);
            lblIMC.Name = "lblIMC";
            lblIMC.Size = new Size(44, 25);
            lblIMC.TabIndex = 2;
            lblIMC.Text = "IMC";
            // 
            // mskPesoAtual
            // 
            mskPesoAtual.Location = new Point(256, 48);
            mskPesoAtual.Mask = "00.0";
            mskPesoAtual.Name = "mskPesoAtual";
            mskPesoAtual.Size = new Size(150, 31);
            mskPesoAtual.TabIndex = 3;
            mskPesoAtual.Validated += mskPesoAtual_Validated;
            // 
            // mskAltura
            // 
            mskAltura.Location = new Point(256, 132);
            mskAltura.Mask = "0.00";
            mskAltura.Name = "mskAltura";
            mskAltura.Size = new Size(150, 31);
            mskAltura.TabIndex = 4;
            mskAltura.Validated += mskAltura_Validated;
            // 
            // mskIMC
            // 
            mskIMC.Location = new Point(256, 222);
            mskIMC.Name = "mskIMC";
            mskIMC.ReadOnly = true;
            mskIMC.Size = new Size(150, 31);
            mskIMC.TabIndex = 5;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(75, 325);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(112, 34);
            btnCalcular.TabIndex = 6;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(283, 325);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(112, 34);
            btnLimpar.TabIndex = 7;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(457, 325);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(112, 34);
            btnSair.TabIndex = 8;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(btnCalcular);
            Controls.Add(mskIMC);
            Controls.Add(mskAltura);
            Controls.Add(mskPesoAtual);
            Controls.Add(lblIMC);
            Controls.Add(lblAltura);
            Controls.Add(lblPesoAtual);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblPesoAtual;
        private Label lblAltura;
        private Label lblIMC;
        private MaskedTextBox mskPesoAtual;
        private MaskedTextBox mskAltura;
        private MaskedTextBox mskIMC;
        private Button btnCalcular;
        private Button btnLimpar;
        private Button btnSair;
    }
}
